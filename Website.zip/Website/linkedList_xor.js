var ref;
function Node(data){
this.data=data;
this.prev=null;
this.next=null;
}

function NodeXOR(data){
this.data=data;
this.addr=null;
}

function addtoHeadXOR(data){
  var node = new Node(data);
  var temp=node;
  node=ref;
  ref=temp;
  node.next=ref;
  ref.prev=node;
}

function addtoTail(data){
  var prevNode=ref;
  while(prevNode.prev!=null){
    prevNode=prevNode.prev;
  }
  var node = new Node(data);
  node.next=prevNode;
  prevNode.prev=node;
}


function CreateList(data){
  ref=new Node(data);
  for(var i=10;i<20;i++){
  addtoTail(i);
  }
  console.log(ref);
}
